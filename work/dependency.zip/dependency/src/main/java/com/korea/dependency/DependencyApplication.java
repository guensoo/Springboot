package com.korea.dependency;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DependencyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DependencyApplication.class, args);
	}

}
